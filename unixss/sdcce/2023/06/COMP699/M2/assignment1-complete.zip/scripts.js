//STEP 1
//var someMonth;
//functionTheMonth 		// function to return current month
//currentMonth 		    // a constant
//var summerMonth; 		// an array of summer months
//myLibraryFunction     // a function

//STEP 2
//"Hello World"
//41
//true
//null

//STEP 3
//var sum = x + y;
//var total = sum * 100 / .5;

//STEP 4
//var strFirstName;
//var strLastName;
//var strAddress;
//var strCity;
//var strState;
//var strZipCode;
//var numYourAge;
//var strReferralSource;
//var blnMayWeContactYou;

//STEP 5
//var strFirstName, strLastName, strAddress = "";
//var strCity = "San Diego";
//var strState = "CA";
//var strZipCode = "92115";
//var numYourAge;
//numYourAge = 42;
//var strReferralSource;
//strReferralSource = "Internet Search";
//var blnMayWeContactYou;
//blnMayWeContactYou = false;

//STEP 6
//var numYourAge = "My age is " + 42;
//window.console.log (numYourAge);
//var blnMayWeContactYou = "May we contact you? " + false;
//window.console.log (blnMayWeContactYou);
//var varNum = 42 + true;
//window.console.log (varNum);

//STEP 7
//function displayMessage() {
//    var message2 = "Hello World Again";
//}
//var message1 = "Hello World";
//window.console.log(message1);
//window.console.log(message2);

//STEP 8
//var someString = 'Who once said, "Only two things are infinite, the universe and human stupidity, and I\'m not sure about the former."';
//window.console.log(someString);

//STEP 9
//var myVariable = null;
//var myVariable2;
//window.console.log(myVariable);
//window.console.log(myVariable2);

//STEP 10
//var strFirstName = "Zak";
//var numZipCode = 92115;
//var isInstructor = true;
//var car = new Object();
//var myVariable;
//window.console.log(typeof strFirstName);
//window.console.log(typeof numZipCode);
//window.console.log(typeof isInstructor);
//window.console.log(typeof car);
//window.console.log(typeof myVariable);

//STEP 11
//window.alert("Hello " + "Zak Ruvalcaba" + ", welcome to the JavaScript class!");

//STEP 12
//var name = "Zak Ruvalcaba";
//window.alert("Hello " + name + ", welcome to the JavaScript class!");

//STEP 13
//var name = "Zak Ruvalcaba";
//var course = "JavaScript";
//window.alert("Hello " + name + ", welcome to the " + course + " class!");

//STEP 14
//var name = "Zak Ruvalcaba";
//var course = "JavaScript";
//window.alert("Hello " + name + ".\nWelcome to the " + course + " class!");

//STEP 15
//var name = window.prompt("What is your name?");
//var course = "JavaScript";
//window.alert("Hello " + name + ".\nWelcome to the " + course + " class!");

//STEP 16
//var name = window.prompt("What is your name?");
//var course = window.prompt("What class are you taking?");
//window.alert("Hello " + name + ".\nWelcome to the " + course + " class!");

//STEP 17
//var x = 10;
//var y = 20;
//window.console.log(x + y);

//STEP 18
//var x = 20;
//window.console.log(x+=20);

//STEP 19
//var x = 20;
//window.console.log(x*=5);

//STEP 20
//var x = 20 % 3;
//window.console.log(x/=1);

//STEP 21
//var x = 20;
//var y = 10;
//if (x > 10 || y < 5) {
//    window.console.log("Congrats!");
//}

//STEP 22
//var x = 20;
//var y = 10;
//if (x === 20 && y !== 10) {
//    window.console.log("true");
//} else {
//    window.console.log("false");
//}

//STEP 23
//var widget = new Object();
//window.console.log(typeof widget);

//STEP 24
//var widget = new Object();
//if (widget instanceof Object) {
//    window.console.log("true");
//}

//STEP 25
//var widget = new Object();
//if (!widget instanceof Object) {
//    window.console.log("true");
//} else {
//    window.console.log("false");
//}