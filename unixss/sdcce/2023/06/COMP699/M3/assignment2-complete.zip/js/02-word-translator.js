let hello = prompt('What language do you want to see "Hello World" in? (es, de, en, fr)')

if (hello === 'es') {
    console.log('Que Onda')
} else if (hello === 'de') {
    console.log('Hallo Welt')
} else if (hello === 'fr') {
    console.log('Bonjour Le Monde')
} else {
    console.log('Hello World')
}