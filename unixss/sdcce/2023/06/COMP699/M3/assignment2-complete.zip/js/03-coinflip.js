let coinflip = Math.round(Math.random())
let choose = prompt('Choose heads or tails (h/t)')

if (coinflip === 0) { //TAILS
    if (choose === 'h') {
        document.write('The flip was tails and you chose heads, you lose.')
    } else {
        document.write('The flip was tails and you chose tails, you win.')
    }
} else if (coinflip === 1) {            //HEADS
    if (choose === 'h') {
        document.write('The flip was heads and you chose heads, you win.')
    } else {
        document.write('The flip was heads and you chose tails, you lose.')
    }
}