let num = parseInt(prompt('Enter a number to begin countdown sequence.'))
while (num >= 0) {
    console.log(num)
    num--
}