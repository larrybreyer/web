let triangle = ''
for (let i = 0; i < 15; i++) {
    console.log(triangle += '#')
}