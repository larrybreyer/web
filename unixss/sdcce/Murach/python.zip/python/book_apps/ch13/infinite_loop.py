def display_message():
    while True:
        print("Press Ctrl+C to stop!")

display_message()
