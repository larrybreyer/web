SELECT *
FROM Movie
WHERE categoryID = 2
