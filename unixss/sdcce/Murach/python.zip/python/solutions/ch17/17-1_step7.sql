SELECT name, year 
FROM Movie
WHERE categoryID = 3
