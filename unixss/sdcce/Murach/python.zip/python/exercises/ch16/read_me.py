# There is no starting point for the exercise for this chapter.
